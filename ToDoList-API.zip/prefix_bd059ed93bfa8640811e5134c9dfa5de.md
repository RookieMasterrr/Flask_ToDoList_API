**简要描述：** 

- 将所有事项设为待办

**请求URL：** 
- ` http://ofeasl.top/api/v1/set_all_undone`
  
**请求方式：**
- PUT 

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|token |是  |string | 登录认证    |
|token在header中添加
 **返回示例**
``` 
{
    "data": "",
    "message": "Change Successfully",
    "status": 0
}
```
 **返回参数说明** 


 **备注** 

