**简要描述：** 

- 查看所有事项

**请求URL：** 
- ` http://ofeasl.top/api/v1/display_all_tasks?page=1 `
  
**请求方式：**
- GET

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|page |否  |int | 页码，默认为1    |
|token |是  |string | 登录认证    |
|token要添加在headers中
 **返回示例**
``` 
{
    "data": [
        {
            "done": false,
            "end_time": "2019.1.2",
            "id": 1,
            "owner": 1,
            "start_time": "2019.1.1",
            "state": "Milk, Cheese, Pizza, Fruit, Tylenol",
            "title": "Buy groceries"
        },
        {
            "done": false,
            "end_time": "2019.2.2",
            "id": 2,
            "owner": 1,
            "start_time": "2019.2.1",
            "state": "Need to find a good Python tutorial on the web",
            "title": "Learn Python"
        },
        {
            "done": false,
            "end_time": "2019.3.2",
            "id": 3,
            "owner": 1,
            "start_time": "2019.3.1",
            "state": "Test_state_3",
            "title": "Test_title_3"
        },
        {
            "done": false,
            "end_time": "2019.3.2",
            "id": 4,
            "owner": 1,
            "start_time": "2019.3.1",
            "state": "Test_state_33333",
            "title": "Test_title_3"
        },
        {
            "done": false,
            "end_time": "2019.3.2",
            "id": 5,
            "owner": 1,
            "start_time": "2019.3.1",
            "state": "Tsssss333",
            "title": "Test_title_3"
        }
    ],
    "message": {
        "current_page": 1,
        "has_next?": false,
        "has_prev": false,
        "max_page": 1,
        "peer_page": 5,
        "total_data": 5
    },
    "status": 0
}
```
 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|data.done |bool   |是否完成|
|data.end_time |string   |结束时间|
|data.id |int   |事项id(系统自动生成)|
|data.owner |int   |事项作者(根据token自动生成)|
|data.start_time |string   |开始时间(系统自动生成)|
|data.state |string   |事项内容|
|data.title |string   |事项标题|
|message.current_page|int|当前页面|
|message.has_next?|bool|是否有下一页|
|message.has_prev|bool|是否有前一页|
|message.max_page|int|最大页数|
|message.peer_page|int|每一页有多少信息|
|message.total_data|int|信息总数|
 **备注** 

