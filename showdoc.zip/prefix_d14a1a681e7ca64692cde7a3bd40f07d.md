**简要描述：** 

- 查看查询历史记录

**请求URL：** 
- ` http://ofeasl.top/api/v1/api/v1/history`
  
**请求方式：**
- GET

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|token |是  |string | 登录认证    |
|token要添加在headers中
 **返回示例**
``` 
{
    "data": [
        "Search_All_Done",
        "Search_All_Undone",
        "Search_All_Undone",
        "Search_All_Undone",
        "Search_All_Done",
        "Search_All_Done",
        "Search_By_Query",
        "Search_By_Query",
        "Search_By_Query",
        "Search_By_Query"
    ],
    "message": "Search Successfully",
    "status": 0
}
```
 **返回参数说明** 

 **备注** 

